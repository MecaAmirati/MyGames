var xBall = 300;
var yBall = 200;
var diamBall = 20;
var raio = diamBall / 2 ;

var velXBall = 6;
var velYBall = 6;

var xRacket = 10;
var yRacket = 150;
var weiRacket = 20;
var heiRacket = 100;

var xRacketIA = 570;
var yRacketIA =150;
var velYIA;
var miss = 0;

var myScore = 0;
var iaScore = 0;

var pong;
var ponto;
var music;

function preload(){
  music = loadSound("trilha.mp3");
  ponto = loadSound("ponto.mp3");
  pong = loadSound("raquetada.mp3");
}

function setup() {
  createCanvas(600, 400);
  music.loop();
}

function draw() {
  background(0);
  ball();
  moveBall();
  border();
  racket();
  colliRacket();
  colliRacketIA();
  myRacket();
  iaRacket();
  moveRacketIA();
  score();
  setScore();
}

function ball(){
  circle(xBall, yBall, diamBall);
}

function moveBall(){
  xBall += velXBall;
  yBall += velYBall;
}

function border(){
  if (xBall + diamBall> width || xBall - diamBall< 0){
    velXBall *= -1;
  }
  if (yBall + diamBall> height || yBall - diamBall < 0){
    velYBall *= -1;
  }
}

function colliRacket(){
  if (xBall - raio < xRacket + weiRacket && 
      yBall - raio < yRacket + heiRacket && 
      yBall + raio > yRacket){
    velXBall *= -1;
    pong.play();
  }
}

function colliRacketIA(){
  if (xBall + raio > xRacketIA && 
      yBall - raio < yRacketIA + heiRacket && 
      yBall + raio > yRacketIA){
    velXBall *= -1;
    pong.play();
  }
  
}

function racket(){
  rect(xRacket, yRacket, weiRacket,heiRacket);
}

function myRacket(){
  if (keyIsDown(UP_ARROW)){
    yRacket -= 10;
  }
  if (keyIsDown(DOWN_ARROW)){
    yRacket += 10;
  }
}

function iaRacket(){
  rect(xRacketIA, yRacketIA, weiRacket,heiRacket);
}

function moveRacketIA(){
  velYIA = yBall - yRacketIA - weiRacket / 2 - 50;
  yRacketIA += velYIA + miss;
  calcMiss();
}

function calcMiss(){
  if (iaScore >= myScore){
    miss += 1;
    if (miss >= 39){
      miss = 100;
    }
  } else {
    miss -=1;
    if (miss <= 40){
      miss = 40;
    }
  }
}

function score(){
  stroke (255);
  textSize (16);
  textAlign (CENTER);
  fill (color(255, 140, 0))
  rect (150 , 10, 40, 20)
  fill(255);
  text(myScore, 170, 26);
  fill (color(255, 140, 0))
  rect (450 , 10, 40, 20)
  fill(255);
  text(iaScore, 470, 26);
}

function setScore(){
  if (xBall > 580){
    myScore += 1;
    ponto.play();
  }
  if (xBall < 20){
    iaScore += 1;
    ponto.play();
  }
}
